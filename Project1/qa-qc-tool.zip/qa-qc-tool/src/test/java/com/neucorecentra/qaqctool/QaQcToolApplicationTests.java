package com.neucorecentra.qaqctool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaQcToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
